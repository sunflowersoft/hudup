./env.sh
ant $1 $2 $3 $4